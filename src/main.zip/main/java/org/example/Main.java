package org.example;

import java.awt.*;

public class Main {

    //C:\Users\vikto\Downloads\chromedriver_win32\chromedriver.exe

    public static void main(String[] args) throws InterruptedException, AWTException {

        FacebookSearch faceS = new FacebookSearch();
        FacebookPost faceP = new FacebookPost();
        FacebookLog faceL = new FacebookLog();
        TestClass test = new TestClass();
        faceS.method();

    }
}